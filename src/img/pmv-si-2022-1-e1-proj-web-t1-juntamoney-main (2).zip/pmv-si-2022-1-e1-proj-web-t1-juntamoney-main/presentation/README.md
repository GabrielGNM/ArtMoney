# Apresentação

Conjunto de slides em um arquivo PowerPoint ou PDF com a apresentação do projeto contemplando todos os itens trabalhados nos demais artefatos.

## Vídeo de apresentação

 [Link para o vídeo](https://drive.google.com/file/d/1vpJCy64xzbK_3eB_R0rZ7e5fVpzYM0l5/view?usp=sharing)
