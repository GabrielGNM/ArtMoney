
# Projeto de Interface

O projeto de interface está organizado em 5 páginas: 
- Página Inicial 
- Páginas individuais para cada perfil financeiro
- Página da calculadora
- Página sobre investimentos
- Quem Somos

O conteúdo foi organizado de modo que forneça aos usuários as melhores opções de como lidar com seu dinheiro baseado em seu perfil financeiro.

## User Flow

![Fluxo do usuário no site](https://user-images.githubusercontent.com/35051593/165000378-c2ef1929-cfbd-4b7f-8a87-21b70dd11dd9.png)

## Wireframes

### Página Inicial
![Wireframe da página inicial](https://user-images.githubusercontent.com/35051593/166176447-5a7d5279-99cf-46d9-930d-81a4f4f7bc77.png)

### Calculadora
![Wireframe da página da Calculadora](https://user-images.githubusercontent.com/35051593/166176622-98ae24af-8881-44ed-b68c-616bb8ddf761.png)

### Página do Perfil 1
![Wireframe da página do perfil 1](https://user-images.githubusercontent.com/35051593/166176481-6787d3a6-49d1-4810-b70f-02f1cb3ae9c7.png)

### Página do Perfil 2
![Wireframe da página do perfil 2](https://user-images.githubusercontent.com/35051593/166176507-ddb25dff-cf9e-420d-abf6-dd7630f10271.png)

### Investimentos
![Wireframe da página de investimentos](https://user-images.githubusercontent.com/35051593/166176581-24a78d50-73cf-477f-979c-dc193bef0a0a.png)

### Quem Somos
![Wireframe da página Quem Somos](https://user-images.githubusercontent.com/35051593/166176536-ce90adac-8ee6-44b9-9504-98b79c17c456.png)

