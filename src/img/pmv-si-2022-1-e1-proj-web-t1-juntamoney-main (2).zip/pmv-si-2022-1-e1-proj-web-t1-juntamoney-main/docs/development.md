# Programação de Funcionalidades

Implementação do sistema descritas por meio dos requisitos funcionais e/ou não funcionais. Deve relacionar os requisitos atendidos os artefatos criados (código fonte) além das estruturas de dados utilizadas e as instruções para acesso e verificação da implementação que deve estar funcional no ambiente de hospedagem.

---
## Páginas dos Perfis

### Requisitos

RF-003	Disponibilizar páginas com informações para cada perfil financeiro


  Para atender o item RF-003, foi desenvolvida 4 páginas dinâmica para disponibilizar a feature das perguntas objetivas sobre o tema e perfil selecionado. A página está acessível em https://icei-puc-minas-pmv-si.github.io/pmv-si-2022-1-e1-proj-web-t1-juntamoney/src/perfil1tema1.html.
  
  ![dinamico](https://user-images.githubusercontent.com/70835031/173421022-1bce1226-40ad-42ca-8ac5-c87c64bd4065.jpeg)

  A página possui, além do seu conteúdo personalizado para o tema escolhido, uma pergunta objetiva ao final sobre o aprendizado exposto anteriormente. Sendo assim o usuário deve clicar em uma resposta e depois clicar em validar, sendo apresentado a seguir a resposta correta em verde, e a errada em vermelho(caso tenha sido marcado a errada)
  
 - Essa feature foi implementada usando JQUERY , com a seguinte estrutura:
  
  
  ```js
 $(document).ready(function(){
  $("#awnser").submit(function(e){
      e.preventDefault();


      const resultado = {
        selecionado : $("input:checked")[0],
        certo : $("[data-resultado='true")[0],

      }

      if(resultado.selecionado == resultado.certo){
        $(resultado.selecionado).parent().addClass("resultado_certo");
      }else{
        $(resultado.selecionado).parent().addClass("resultado_errado");
        $(resultado.certo).parent().addClass("resultado_certo");
      }

      $("input[type=submit").prop("disabled",true);
  })
});

  ```
  
  ---

## Calculadora

### Requisitos

- RF-005 - Disponibilizar seção com curadoria de conteúdos sobre Educação Financeira ou Investimento	

Para atender o item RF-004, foi desenvolvida uma página responsável para disponibilizar a feature da calculadora para objetivos financeiros. A página está acessível em https://icei-puc-minas-pmv-si.github.io/pmv-si-2022-1-e1-proj-web-t1-juntamoney/src/calculadora.html.

<img width="1786" alt="image" src="https://user-images.githubusercontent.com/35051593/173257643-c3a43a86-c7a3-4ff8-b9a7-7d2790707141.png">
<img width="1786" alt="image" src="https://user-images.githubusercontent.com/35051593/173257685-e209b639-be0f-4571-8d49-79b8567dc135.png">

A página possui além do formulário e a visualização do resultado, funcionalidades como:
- Validação caso algum campo não esteja completo
<img width="1786" alt="image" src="https://user-images.githubusercontent.com/35051593/173257798-21f87a59-8106-43a4-9859-437d5dc2239a.png">
- Caso o gasto seja maior que a renda, um estado que recomenda nosso conteúdo sobre educação financeira para o usuário
<img width="1786" alt="image" src="https://user-images.githubusercontent.com/35051593/173257754-e0cb0212-ec8c-4bcb-b308-50f1b4f7f3fb.png">
  - Nesse caso, o botão "Aprenda como sair do negativo" leva o usuário para a página do tema 1 do perfil Iniciante em Investimentos.

- Possibilidade de salvar um objetivo e acessá-lo novamente. Também mostra um aviso que o dado foi salvo com sucesso.
<img width="1786" alt="image" src="https://user-images.githubusercontent.com/35051593/173257811-bbc26042-d168-4e45-95a0-57ddc2c13be7.png">
  - Essa feature foi implementada usando a API de Local Storage do navegador, com a seguinte estrutura de dados:
  
  
  ```js
  [
    {
      "nomeDoObjetivo": string;
      "dinheiroQueSobra": number;
      "porcentagemDoValor": number;
      "tempoAteJuntar": number;
      "valorDoObjetivo": number;
    }
  ]
  ```
  
  ---

## API financeira

### Requisitos
  -RF-006- Disponibilizar API financeira com dados sobre o mercado financeiro em tempo real
  
  Para atender o item RF-006, foi desenvolvida uma página dinâmica para disponibilizar a feature da API de dados sobre o mercado financeiro. A página está acessível em https://icei-puc-minas-pmv-si.github.io/pmv-si-2022-1-e1-proj-web-t1-juntamoney/src/investimentos.html.
  
  ![api](https://user-images.githubusercontent.com/70835031/173420308-035e9c42-5af3-4717-ba0c-9e50c1b2d6eb.jpeg)
  
  A página possui uma tabela com a cotação de diferentes moedas em tempo real, sendo apresentado o ultimo valor negociado da moeda toda vez que a página é carregada.
  
 - Essa feature foi implementada usando o fetch javascrypt, com a seguinte estrutura por moeda:
  
  
  ```js
  function fetchApiData() {
    fetch('https://economia.awesomeapi.com.br/USD/1')
        .then(response => response.json())
        .then(data => {
            const list = document.querySelector('#fill_list1');

            data.map((item) => {
                const li = document.createElement('span');


                li.setAttribute('id', item.id);

                li.innerHTML = item.low;

                list.appendChild(li);

            })
        })
     }

  ```
  
  ---
  
