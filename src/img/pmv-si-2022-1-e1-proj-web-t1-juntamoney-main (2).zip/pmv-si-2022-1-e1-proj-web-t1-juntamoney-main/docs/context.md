# Introdução

Em 2022, o percentual de brasileiros endividados é o maior em 12 anos. 77% das famílias fecharam o mês com alguma dívida, de acordo com uma pesquisa da Confederação Nacional do Comércio de Bens, Serviços e Turismo. Isso se dá principalmente pela queda na renda média das pessoas, aliado ao aumento da inflação, o que reduz muito o poder de compra do brasileiro que, na tentativa de não diminuir a qualidade de vida, acaba endividado.

Além disso, uma pesquisa da PoderData mostrou que, apenas 10% dos brasileiros investem ou já investiu na IBOVESPA, enquanto em países como EUA essa porcentagem se encontra em 65%, mostrando que o problema não é apenas nas pessoas que estão no vermelho, e sim na qualidade da educação financeira do brasileiro.

Sendo assim esse projeto terá o intuito de atender a 2 perfis financeiros, o primeiro sendo as pessoas endividadas, que após uma série de treinamentos colocados em prática irá progredir para o perfil 2, Pessoas que buscam a estabilização financeira, onde será ensinado a como lidar da melhor forma com o seu dinheiro., dependendo do perfil de risco da pessoa e de seus objetivos financeiros.



## Problema

Na história do Brasil, a inflação marcou gerações. Nos anos 60 e 70, a inflação média anual foi de 38%. Na década de 1980, o Brasil viveu uma inflação descontrolada na casa de 330% ao ano e chegou à hiperinflação na década de 1990. 

Durante o processo inflacionário, o crédito para o consumo era quase inexistente. Quando a inflação foi controlada e o crédito voltou, a população se tornou vítima do crédito concedido de forma indisciplinada. Assim, a inadimplência ficou elevada e, para compensar, os agentes financeiros passaram a cobrar taxas de juros altas, que não correspondiam com o desenvolvimento econômico.

O descontrole financeiro, decorrente da falta de educação financeira e as crises que afetam o país, causa enormes transtornos para pessoas e suas famílias. Problemas financeiros e o superendividamento são causas frequentes de brigas em famílias, problemas no trabalho e na saúde, tanto física quanto mental. Pessoas endividadas estão esgotadas com os problemas financeiros, uma vez que isso afeta todas as áreas da sua vida, principalmente sua sobrevivência.

Visto isso, não podemos simplificar a equação: precisamos lembrar que o Brasil é um país extremamente desigual. Para quem está na linha da pobreza e lutando diariamente para sobreviver, a educação financeira é um desafio enorme, necessitando urgentemente de programas sociais para auxílio, para que consigam condições mínimas de vida. 

Entretanto, a classe média, com condições de uma vida com certo conforto, precisa aprender a importância da previdência oficial, a utilizar o crédito de forma consciente, a fazer uma reserva para emergência e, principalmente, a valorizar a educação como fator de progresso social. E a classe alta, precisa aprender a fazer uma reserva de aposentadoria ao invés de consumir desenfreadamente. 

O cenário da educação financeira brasileira é complexo e desafiador. Por isso, é necessário fornecer uma solução acessível para a população: Uma plataforma que reúna conteúdos gratuitos, orientações e dicas para que seus usuários possam aprender como lidar e planejar suas finanças.

## Objetivos

**Objetivo geral**: Desenvolver uma aplicação web que auxilie indivíduos a organizarem sua vida financeira.

**Objetivos específicos**:

- Apresentar ferramentas que norteiem o uso responsável da renda líquida dos usuários;
- Fornecer informações que facilitem a vida financeira dos usuários;
- Elucidar meios alternativos de endividados/super-endividados quitarem suas dívidas. 

## Justificativa

Vivemos em um mundo no qual o sistema predominante econômico é o capitalismo, com isso, a necessidade de ter um conhecimento sobre finanças se torna cada vez mais de suma importância. 

A educação financeira vai além de aprender a economizar, cortar gastos sem necessidade, juntar e poupar dinheiro. Infelizmente, no Brasil, a educação financeira ainda está longe de alcançar um estágio necessário e juntamente a isso, desenvolvemos um projeto no qual seria apresentar soluções e auxiliar o crescimento financeiro individual de cada cidadão. Pesquisa do SPC (Serviço de Proteção ao Crédito) e pela Confederação Nacional de Dirigentes Lojistas (CNDL) mostra que 6 em cada 10 brasileiros sendo 58% argumentam que nunca, ou apenas às vezes, buscam compreender e entender melhor o controle da vida financeira, e 17% dos consumidores, frequentemente, precisam recorrer à cartão de crédito, a um terceiro ou cheque especial para sanear suas dívidas, e esse indice cresce ainda mais (24%) nos mais jovens que fazendo compras impulsivante acabam se debruçando em dívidas desnecessárias. 

Vista disso, o site irá auxiliar diretamente a esse público com informações e direcionamento a como investir bem seu dinheiro e conscientização sobre.

## Público-Alvo
Notamos que, trabalhando com 2 tipos de perfis (pessoas endividadas e pessoas que buscam a estabilização financeira) conseguimos abranger um número expressivo de pessoas que queiram aderir uma nova realidade financeira.

### Perfil 1: Pessoas endividadas
Percentual de brasileiros endividados é o maior em 12 anos. Em março, 77% das famílias fecharam o mês com alguma dívida, devido principalmente à inflação e ao achatamento da renda. No trimestre que terminou em fevereiro, a renda média do brasileiro atingiu o menor patamar em 10 anos. Iremos auxiliar essas pessoas a saírem desse "terror" financeiro, com planejamentos e dicas com o intuito de quitar suas dívidas.

### Perfil 2: Pessoas que buscam a estabilização financeira
De maneira simples, trabalharemos com a educação financeira e como utilizar o dinheiro de modo funcional e correto. Iremos auxiliar a pessoa usuária a compreender melhor os produtos e serviços financeiros, possibilitando a fazer melhores escolhas diante o momento atual da economia.
