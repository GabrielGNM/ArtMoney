# Especificações do Projeto

## Personas

PROFISSIONAIS DE CARTEIRA ASSINADA. EXEMPLOS: MOTORISTA, VENDEDOR, COZINHEIROS, PROFISSIONAIS DA CONSTRUÇÃO CIVIL, PROFISSIONAIS E PRODUÇÃO, EMPREGADAS DOMESTICA e ATENDENTE.

**ADULTO DE MEIA–IDADE (35–59)**

### Mini-Bio

Usuários da Junta Money são pessoas casadas e que trabalham maior parte da sua semana que não tem tempo para verificar seus gastos e ganhos, com isso acaba destinando seu dinheiro de forma errada. Quem vai usar o Junta Money está procurando um lugar centralizado onde vai fornecer informações que facilitem a sua vida financeira.

### Detalhes Pessoais

* Localização: Brasil
* Renda Familiar: De R$1.501,00 a R$3.500,00
* Nível Educacional: Ensino Médio completo ou incompleto
* Status de Relacionamento: Casado(a)

### Carreira 

* Empresa: Comércio, Fábrica, Restaurante, Empresa de ônibus, Canteiro de obras.
* Tamanho da Empresa: Média para grande empresa.
* Responsabilidades Profissionais: É um trabalhador fundamental para a realização de trabalhos mais essenciais dentro da sua empresa.
* Objetivos: O usuário é mensurado pela sua carga horária se ele trabalha muito é um bom funcionário. Seus objetivos é dentro da sua carga horária de trabalho produzir o máximo possível mantendo uma qualidade aceitável.
* Desafios: Principal dor seria que o usuário tem uma carga horaria exaustiva de trabalho e assim não consegue estudar onde destinar melhor seu dinheiro. Existem várias informações na internet e assim ele fica perdido. A persona da Junta Money está procurando um lugar centralizado de informações onde vai ajudar ele destinar melhor seu dinheiro.

### Canais de Comunicação

Instagram, Youtube, Facebook WhatsApp e Tv aberta.

## Histórias de Usuários

Com base na análise das personas forma identificadas as seguintes histórias de usuários:

| EU COMO... `PERSONA`                  | QUERO/PRECISO ... `FUNCIONALIDADE`                                                       | PARA ... `MOTIVO/VALOR`                                                                                         |
| ------------------------------------- | ---------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| Pessoa endividada                     | Encontrar informações sobre educação financeira                                          | Aprender a planejar uma forma de quitar minhas dívidas                                                          |
| Pessoa trabalhadora com renda estável | Encontrar informações sobre educação financeira                                          | Aprender técnicas e ferramentas a fim de melhor utilizar minha renda líquida de forma responsável               |
| Pessoa endividada                     | Encontrar uma ferramenta para calcular de forma simplificada meus ganhos e gastos        | Planejar em quanto tempo consigo chegar no meu objetivo (quitar dívidas)                                        |
| Pessoa trabalhadora com renda estável | Encontrar uma ferramenta para calcular de forma simplificada meus ganhos e gastos        | Planejar em quanto tempo consigo chegar no meu objetivo (viagens, compras, construir uma reserva de emergência) |
| Pessoa curiosa com finanças           | Encontrar uma curadoria de conteúdos e artigos sobre educação financeira e investimentos | Aprender a administrar meu dinheiro e conseguir fazer investimentos simples∏                                    |                                 |
            

## Requisitos

As tabelas que se seguem apresentam os requisitos funcionais e não funcionais que detalham o escopo do projeto.

### Requisitos Funcionais

|ID    | Descrição do Requisito  | Prioridade |
|------|-----------------------------------------|----|
|RF-001| Disponibilizar área com os perfis financeiros abordados | ALTA | 
|RF-002| Disponibilizar funcionalidade para seleção de perfil | ALTA |
|RF-003| Disponibilizar páginas com informações para cada perfil financeiro | ALTA |
|RF-004| Disponibilizar seção com uma calculadora para atingir objetivos financeiros| MÉDIA |
|RF-005| Criar funcionalidade para ver a cotação de moedas em tempo real| MÉDIA |
|RF-006| Disponibilizar seção com curadoria de conteúdos sobre Educação Financeira ou Investimento| BAIXA |


### Requisitos não Funcionais

|ID     | Descrição do Requisito  |Prioridade |
|-------|-------------------------|----|
|RNF-001| O sistema deve ser responsivo para rodar em qualquer plataforma | ALTA | 
|RNF-002| O sistema não apresentará aos usuários quaisquer dados de cunho privativo. |  ALTA | 
|RNF-003| O sistema deverá atender às normas legais, tais como padrões, leis, etc. |  MEDIA | 
|RNF-004| A página deverá ter disponibilidade em 90% do tempo|  BAIXA | 
|RNF-005| Deve processar requisições do usuário em no máximo 3s |  BAIXA | 


## Restrições

O projeto está restrito pelos itens apresentados na tabela a seguir.

|ID| Restrição                                             |
|--|-------------------------------------------------------|
|01| O projeto deverá ser entregue até o final do semestre, não ultrapassando a data inicial de apresentação da solução em 27/06/2022. |
|02| O front-end do projeto será desenvolvido com HTML, CSS e JavaScript.|
|03| Não será desenvolvido o back-end desse projeto.|
|04| Todas as etapas do projeto devem ser concluídas dentro dos prazos estipulados no planejamento.|
