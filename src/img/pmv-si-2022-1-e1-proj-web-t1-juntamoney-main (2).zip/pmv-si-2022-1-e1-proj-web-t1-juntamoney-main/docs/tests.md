# Plano de Testes de Software

## Resultados Esperados

| Nº Teste | Página           | Cenário de teste                                                                                                                                                                                                                                 |
| -------- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| TF-001   | Calculadora      | Ao acessar a página, é esperado que a página carregue com o formulário disponível para ser preenchido.                                                                                                                                           |
| TF-002   | Calculadora      | Ao preencher o formulário, é esperado que a página carregue o estado do resultado do objetivo.                                                                                                                                                   |
| TF-003   | Calculadora      | Ao tentar enviar o formulário com algum dado faltando, a página deve permanecer no formulário e mostrar uma mensagem de erro sobre os campos que faltam.                                                                                         |
| TF-004   | Calculadora      | Ao preencher o formulário, caso o gasto mensal seja maior que a renda mensal, a página deve mostrar uma seção recomendando que o usuário leia os conteúdos sobre educação financeira da página.                                                  |
| TF-005   | Calculadora      | No estado de recomendação de estudo, o botão "Aprenda como sair do negativo" deve levar para a página `/perfil1tema1.html`                                                                                                                       |
| TF-006   | Calculadora      | Ao salvar um objetivo, um feedback para o usuário informando que a operação foi realizada deve aparecer.                                                                                                                                         |
| TF-007   | Calculadora      | Caso o usuário tenha objetivos salvos, devem existir cards clicáveis que levam para os respectivos objetivos.                                                                                                                         |
| TF-008   | Perfil           | Ao clicar em um dos temas na lateral esquerda da página, é esperado que carregue a página com o conteudo sobre o tema especificado.                                                                                                              |
| TF-009   | Perfil           | Ao clicar em alguma das respostas objetivas ao final do texto deve ser marcada a resposta como escolha temporária.                                                                                                                               |
| TF-010   | Perfil           | Ao clicar em enviar e tiver alguma resposta temporária escolhida anteriormente deve ser validada a questão e mostrar qual a resposta correta.                                                                                                    |
| TF-011   | Perfil           | Ao ter a resposta enviada não deve ser possível envia-la novamente ate a página ser recarregada.                                                                                                                                                 |
| TF-012   | Geral            | Ao acessar a página é esperado que seja encontrado um header com o Nome do Grupo,Calculadora,Investimentos e "Quem somos",podendo ser clicada diante da vontade do acessor.                                                                      |
| TF-013   | Geral            | A  última parte da página é o footer,diante disso é onde se localiza o Nome do Grupo,Sobre o Site ( "Quem Somos" e "Fale Conosco") e Veja o Site ( "Investimentos" e "Calculadora") ambos em parênteses são clicavéis e direcionavéis. |
| TF-014   | Geral            | Todos os links devem estar funcionando |
| TF-015   | Geral            | Todos os vídeos devem estar funcionando 
| TF-016 | Quem Somos | Ao clicar na aba "Quem somos" será redirecionado para a parte onde falamos mais sobre nosso projeto e os criadores dele.
| TF-017 | Quem Somos | A primeira parte apresenta brevemente quem somos, já na segunda apresentamos nossa proposta e posteriormente o intuito do nosso site.    
| TF-018 | Quem Somos | Em seguida é apresentado os nomes do todos os membros da nossa equipe.
# Registro de Testes de Software
| Nº Teste | Página | Resultado do Teste | Bugs? |
|----|-----------------------------------------|----|----|
|RTF-001| Calculadora | Formulário disponível e funcional na página. | NÃO |
|RTF-002| Calculadora | Resultado do objetivo é mostrado como esperado caso o usuário preencha todos os campos. | NÃO |
|RTF-003| Calculadora | Mensagem de erro aparece como esperado caso o usuário não preencha todos os campos. | NÃO |
|RTF-004| Calculadora | A seção é mostrada como esperado caso o usuário tenha uma renda menor que o gasto. | NÃO |
|RTF-005| Calculadora | Ao clicar no botão, o usuário é redirecionado para a página esperada. | NÃO |
|RTF-006| Calculadora | O feedback que o objetivo foi salvo é mostrado como esperado. | NÃO |
|RTF-007| Calculadora | Dado que o usuário salvou um objetivo, ele é mostrado na lista de objetivos salvos como esperado. | NÃO |
|RTF-008| Perfil | A pagina é devidamente mudada para o tema escolhido, tanto os textos quanto videos e perguntas. | NÃO |
|RTF-009| Perfil | A resposta é marcada corretamente. | NÃO |
|RTF-010| Perfil | A resposta correta aparece em verde e a vermelha em vermelho conforme previsto. | NÃO |
|RTF-011| Perfil | o botão de validar a resposta é trancado corretamente não permitindo o envio duplo da resposta. | NÃO |
|RTF-012| Geral  | O Header carrega corretamente. | NÃO |
|RTF-013| Geral  | O Footer carrega corretamente. | NÃO |
|RTF-014| Geral  | Todos os links funcionaram corretamente. | NÃO |
|RTF-015| Geral  | Todos os vídeos funcionaram corretamente. | NÃO |
|RTF-016| Quem Somos  | o link funcionou corretamente. | NÃO |
|RTF-017| Geral  | Todos os conteúdos foram apresentados corretamente. | NÃO |
|RTF-018| Geral  | Todos os conteúdos foram apresentados corretamente. | NÃO |
## Avaliação
### 20/06/2022

Nessa data, foram feitos os testes das páginas de Perfil e Calculadora em ambiente de produção. 
Nenhum bug foi encontrado e todos os casos de teste funcionaram como esperado. 

### 27/06/2022

Nesta data foi feita o plano de teste com uma terceira pessoa e abaixo está documentado passo a passo dos registros. 

O entrevistado abriu o seguinte link dado. 

Logo após abrir, imediatamente apresentou-se a tela inicial do site. 

Com curiosidade, ele rolou a tela para ler mais sobre.

Como ele tinha o perfil de investidor ficou animado em ver que ali tinha essa opção pra ele poder se informar mais.

Com isso, clicou em "Saiba mais" sobre o perfil dele.

Assim que abriu logo encontrou com um video da plataforma "youtube" na qual utilizamos como exemplo.

Achou interessante o que viu e como foi apresentado.

Leu mais um pouco sobre seu perfil de investidor e posteriormente quando rolou mais a página, encontrou uma pergunta com múltipla escolha sobre o que ele acabou de aprender e marcou corretamente.

Desceu mais um pouco o site e encontrou as opções "Quem somos", "Fale conosco", "Investimentos" e "Calculadora".

Ele resolveu primeiro abrir a calculadora para calcular algum de seus objetivos.

Calculou e anotou quanto tempo ele deveria guardar a quantia indicada para ele realizar esse objetivo.

Abriu o botão "Quem somos" e leu mais sobre o nosso projeto.

Abriu o botão "Investimentos" leu a página e identificou seu perfil de investidor como "Moderado".

Considerações:

O site funcionou perfeitamente e atendeu as expectativas do entrevistado.
