# JuntaMoney

`CURSO: Sistemas de Informação`

`DISCIPLINA: Projeto - Aplicações Web`

`SEMESTRE: 1º`

O JuntaMoney nasceu com o intuito de ajudar diferentes grupos de pessoas a realizar seu objetivo financeiro. Sendo assim, nos disponibilizamos conteúdos gratuitos de qualidade para pessoas endividadas, sem dívidas, e investidores. A Plataforma definirá perfis selecionáveis e, com base na escolha do usuário, apresentará soluções referente a cada caso! Esse processo facilita a busca do conteúdo desejado dentro do site e possibilita que o usuário atenda sua necessidade com mais eficiência.

[Link para o sistema](https://icei-puc-minas-pmv-si.github.io/pmv-si-2022-1-e1-proj-web-t1-juntamoney/src/index.html)


## Integrantes

* Amanda Costa Dutra
* Artur Bani Lacerda
* Bruno Soares Reis
* Luana Dos Santos Pimentel Silva
* Pedro Henriques Angelo Andrade Barros
* Renato Cifuentes Dias de Araújo Neto


## Orientador

* Hugo Bastos De Paula

# Planejamento

| Etapa         | Período                   | Atividades |
|  :----:   |  :----:               | ----------- |
| ETAPA 1       | 07/03/2022 - 01/04/2022   |[Documentação de Contexto](docs/context.md) <br> [Especificação do Projeto](docs/especification.md) |
| ETAPA 2       | 04/04/2022 - 29/04/2022   |[Projeto de Interface](docs/interface.md) <br> [Template Padrão](docs/template.md) |
| ETAPA 3       | 02/05/2022 - 27/05/2022   |[Programação de Funcionalidades - HTML e CSS](docs/development.md) |
| ETAPA 4       | 30/05/2022 - 24/06/2022   |[Programação de Funcionalidades - Javascript](docs/development.md) <br> [Testes de Software ](docs/tests.md) |
| ETAPA 5       | 27/06/2022 - 08/07/2022   | [Apresentação](presentation/README.md) |

# Código

<li><a href="src/README.md"> Código Fonte</a></li>

# Apresentação

<li><a href="presentation/README.md"> Apresentação da solução</a></li>

